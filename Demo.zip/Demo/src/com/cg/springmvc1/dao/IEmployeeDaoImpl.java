package com.cg.springmvc1.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvc1.dto.Employee;

@Repository("employeedao")
public class IEmployeeDaoImpl implements IEmployeeDao {

	@PersistenceContext
	EntityManager entitymanger;
	
	@Override
	public int addEmployeeData(Employee emp) {
	 entitymanger.persist(emp);
	 entitymanger.flush();
		return emp.getEmpId();
	}

	@Override
	public List<Employee> showAllEmployee() {
		Query query1=entitymanger.createQuery("FROM Employee");
		List<Employee> myList=query1.getResultList();
		return myList;
	}

	@Override
	public void deleteEmployee(int empId) {
	Query query2=entitymanger.createQuery("DELETE FROM Employee WHERE empId=:eid");
	query2.setParameter("eid", empId);
	query2.executeUpdate();
	}

	@Override
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub

	}

	@Override
	public Employee searchEmployee(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
