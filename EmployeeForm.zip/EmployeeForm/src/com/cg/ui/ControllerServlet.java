package com.cg.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.entity.EmployeeDetails;

/**
 * Servlet implementation class ControllerServlet
 */
@WebServlet("/ControllerServlet")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		EmployeeDetails emp = new EmployeeDetails();
		HttpSession session = request.getSession();
		String strid = request.getParameter("txtId");
		if (strid != null) {
			int id = Integer.parseInt(strid);
			
		emp.setId(id);
		
		
		}
		
		String strname = request.getParameter("txtName");
		if (strname != null) {
		
			emp.setName(strname);
		}
		
		String strsalary = request.getParameter("txtSalary");
		if (strsalary!= null) {
			double salary= Double.parseDouble(strsalary);
			emp.setSalary(salary);
		}
		
		String strDept = request.getParameter("txtDept");
		if (strDept != null) {
			emp.setDept(strDept);
		}
		
	session.setAttribute("employee",emp);
/*		
session.setAttribute("id", strid);
session.setAttribute("name", strname);
session.setAttribute("salary", strsalary);
session.setAttribute("Dept", strDept);*/

		/*RequestDispatcher dispatcher = request.getRequestDispatcher("ViewServlet");
		dispatcher.forward(request, response);*/

response.sendRedirect("ViewServlet");
	}

}
