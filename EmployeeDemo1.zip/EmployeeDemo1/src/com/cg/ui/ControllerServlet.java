package com.cg.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.entity.EmployeeDetails;

/**
 * Servlet implementation class ControllerServlet
 */
@WebServlet("/ControllerServlet")
public class ControllerServlet extends HttpServlet {
	static Map<Integer, EmployeeDetails> map=new HashMap<>();

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		EmployeeDetails emp = new EmployeeDetails();

		boolean res = true;
		try{
		String strid = request.getParameter("txtId");
		if (!strid.matches("[0-9]{1,10}")) {
			out.println("Enter the valid id");
			res = false;
		} else {

			int id = Integer.parseInt(strid);
			emp.setId(id);
		}

		String strname = request.getParameter("txtName");
		if (!strname.matches("[a-z]{1,10}")) {
			out.println("enter the valid name\n");
			res = false;
		} else {
			emp.setName(strname);
		}

		String strsalary = request.getParameter("txtSalary");
		if (!strsalary.matches("[0-9]{4,10}")) {
			res = false;
			out.println("enter the valid salary/n");
		} else {
			double salary = Double.parseDouble(strsalary);
			emp.setSalary(salary);
		}

		String strDept = request.getParameter("txtDept");
		if (!strDept.matches("[a-z]{1,10}")) {
			res = false;
			out.println("enter the valid dept/n");
		} else {
			emp.setDept(strDept);
		}

		map.put(emp.getId(),emp);
		if (res == true) {
			session.setAttribute("employee", map);
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("Success.jsp");
			dispatcher.forward(request, response);
		} else {

			RequestDispatcher dispatcher = request
					.getRequestDispatcher("Employee.jsp");
			dispatcher.include(request, response);
		}
		}catch(Exception e){
			out.print("enter valid details");
		}
	}
}
