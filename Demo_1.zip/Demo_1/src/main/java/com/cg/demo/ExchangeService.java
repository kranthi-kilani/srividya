package com.cg.demo;

public interface ExchangeService {

	
	public double getExchangeRate();
}
