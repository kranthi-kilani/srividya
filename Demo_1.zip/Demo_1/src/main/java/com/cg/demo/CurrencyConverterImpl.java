package com.cg.demo;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class CurrencyConverterImpl implements CurrencyConverter {
	
	@Autowired
	private ExchangeService exchangeService;
	
	public CurrencyConverterImpl() {
	System.out.println("");
	}
	@Autowired
	public CurrencyConverterImpl(ExchangeService exchangeService) {
		super();
		this.exchangeService = exchangeService;
	}
	@PostConstruct
	void init(){
		System.out.println("init()");
		
	}
	@PreDestroy
	void destroy(){
		System.out.println("destroy()");
	}
	
//setters and getters
	public ExchangeService getExchangeService() {
		System.out.println("getExchangeService()");
		return exchangeService;
	}

	public void setExchangeService(ExchangeService exchangeService) {
		System.out.println("setExchangeService()");
		this.exchangeService = exchangeService;
	}
//default constructor
	

	public double dollarsToRupees(double dollars) {
		System.out.println("dollarsToRupees()");
		return dollars * exchangeService.getExchangeRate();
	}

}
