package com.cg.demo;

public interface CurrencyConverter {
	
	public double dollarsToRupees(double dollars);
	
	
}
